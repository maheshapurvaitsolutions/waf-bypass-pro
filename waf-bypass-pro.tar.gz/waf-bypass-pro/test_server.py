#!/usr/bin/env python3
"""
Vulnerable Test Server for WAF Bypass Pro Testing

This is a simple vulnerable web application to test WAF bypass techniques.
WARNING: Only use for testing purposes!
"""

import os
import sqlite3
from flask import Flask, request, render_template_string, jsonify
from jinja2 import Template
import subprocess

app = Flask(__name__)
app.config['SECRET_KEY'] = 'test-key-123'

# Initialize SQLite database
def init_db():
    conn = sqlite3.connect('test.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            username TEXT,
            password TEXT
        )
    ''')
    cursor.execute("INSERT OR IGNORE INTO users (id, username, password) VALUES (1, 'admin', 'password123')")
    cursor.execute("INSERT OR IGNORE INTO users (id, username, password) VALUES (2, 'user', 'secret')")
    conn.commit()
    conn.close()

# Basic response
@app.route('/')
def index():
    return '''
    <html>
    <head><title>Test Vulnerable Application</title></head>
    <body>
        <h1>Vulnerable Test Application</h1>
        <p>This is a test application for WAF bypass testing.</p>
        <ul>
            <li><a href="/sqli?id=1">SQL Injection Test</a></li>
            <li><a href="/xss?name=test">XSS Test</a></li>
            <li><a href="/rce?cmd=whoami">RCE Test</a></li>
            <li><a href="/lfi?file=test.txt">LFI Test</a></li>
            <li><a href="/ssti?name=test">SSTI Test</a></li>
        </ul>
    </body>
    </html>
    '''

# SQL Injection vulnerable endpoint
@app.route('/sqli')
def sqli():
    user_id = request.args.get('id', '1')
    
    try:
        conn = sqlite3.connect('test.db')
        cursor = conn.cursor()
        
        # Vulnerable SQL query
        query = f"SELECT * FROM users WHERE id = {user_id}"
        cursor.execute(query)
        result = cursor.fetchall()
        
        conn.close()
        
        if result:
            return f"<h1>User found:</h1><p>{result}</p><br><small>Query: {query}</small>"
        else:
            return f"<h1>No user found</h1><br><small>Query: {query}</small>"
            
    except Exception as e:
        return f"<h1>SQL Error:</h1><p>{str(e)}</p><br><small>Query: SELECT * FROM users WHERE id = {user_id}</small>"

# XSS vulnerable endpoint  
@app.route('/xss')
def xss():
    name = request.args.get('name', 'Guest')
    
    # Vulnerable to XSS
    html = f'''
    <html>
    <head><title>XSS Test</title></head>
    <body>
        <h1>Hello {name}!</h1>
        <p>Your input was: {name}</p>
    </body>
    </html>
    '''
    
    return html

# RCE vulnerable endpoint
@app.route('/rce')
def rce():
    cmd = request.args.get('cmd', 'echo hello')
    
    try:
        # Vulnerable command execution
        result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, timeout=5)
        return f"<h1>Command Output:</h1><pre>{result.decode()}</pre><br><small>Command: {cmd}</small>"
    except subprocess.TimeoutExpired:
        return "<h1>Command timed out</h1>"
    except Exception as e:
        return f"<h1>Command Error:</h1><p>{str(e)}</p><br><small>Command: {cmd}</small>"

# LFI vulnerable endpoint
@app.route('/lfi')
def lfi():
    filename = request.args.get('file', 'test.txt')
    
    try:
        # Vulnerable file inclusion
        with open(filename, 'r') as f:
            content = f.read()
        return f"<h1>File Contents:</h1><pre>{content}</pre><br><small>File: {filename}</small>"
    except Exception as e:
        return f"<h1>File Error:</h1><p>{str(e)}</p><br><small>File: {filename}</small>"

# SSTI vulnerable endpoint
@app.route('/ssti')
def ssti():
    name = request.args.get('name', 'World')
    
    try:
        # Vulnerable template injection
        template_str = f"Hello {name}!"
        template = Template(template_str)
        result = template.render()
        return f"<h1>Template Result:</h1><p>{result}</p><br><small>Template: {template_str}</small>"
    except Exception as e:
        return f"<h1>Template Error:</h1><p>{str(e)}</p><br><small>Template: Hello {name}!</small>"

# Protected endpoint (simulates WAF protection)
@app.route('/protected')
def protected():
    user_input = request.args.get('input', '')
    
    # Simple WAF simulation
    blocked_patterns = [
        'script', 'alert', 'onclick', 'onerror', 'onload',
        'union', 'select', 'drop', 'insert', 'update', 'delete',
        '../', '/etc/', 'passwd', 'cmd', 'exec'
    ]
    
    for pattern in blocked_patterns:
        if pattern.lower() in user_input.lower():
            return f'''
            <html>
            <head><title>Blocked by WAF</title></head>
            <body style="background-color: #ffe6e6;">
                <h1 style="color: red;">🚫 Request Blocked by Web Application Firewall</h1>
                <p><strong>Reason:</strong> Suspicious pattern detected: <code>{pattern}</code></p>
                <p><strong>Your input:</strong> <code>{user_input}</code></p>
                <p><strong>Block ID:</strong> WAF-{hash(user_input) % 10000}</p>
                <hr>
                <small>Simulated WAF Protection - Test Environment</small>
            </body>
            </html>
            ''', 403
    
    return f'''
    <html>
    <head><title>Request Allowed</title></head>
    <body style="background-color: #e6ffe6;">
        <h1 style="color: green;">✅ Request Allowed</h1>
        <p><strong>Your input:</strong> <code>{user_input}</code></p>
        <p>The WAF did not detect any malicious patterns.</p>
    </body>
    </html>
    '''

@app.route('/health')
def health():
    return jsonify({'status': 'ok', 'message': 'Test server is running'})

if __name__ == '__main__':
    init_db()
    
    # Create test file for LFI
    with open('test.txt', 'w') as f:
        f.write('This is a test file for LFI testing.\nFile contents loaded successfully!')
    
    print("Starting vulnerable test server...")
    print("WARNING: This server is intentionally vulnerable!")
    print("Only use for testing WAF bypass techniques.")
    print("\nEndpoints:")
    print("  http://localhost:5000/ - Main page")
    print("  http://localhost:5000/sqli?id=1 - SQL Injection")
    print("  http://localhost:5000/xss?name=test - XSS")
    print("  http://localhost:5000/rce?cmd=whoami - RCE")
    print("  http://localhost:5000/lfi?file=test.txt - LFI")
    print("  http://localhost:5000/ssti?name=test - SSTI")
    print("  http://localhost:5000/protected?input=test - WAF Protected")
    
    app.run(host='127.0.0.1', port=5000, debug=False)

