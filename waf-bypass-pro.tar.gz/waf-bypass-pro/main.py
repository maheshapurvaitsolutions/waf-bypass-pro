#!/usr/bin/env python3
"""
WAF Bypass Pro - Advanced Web Application Firewall Bypass Tool

A comprehensive tool for testing and bypassing Web Application Firewalls (WAFs)
using various evasion techniques and payload mutations.

Author: Security Research Team
Version: 1.0.0
License: Educational Use Only
"""

import sys
import os
import argparse
from pathlib import Path

# Add src directory to Python path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from src.core.main_controller import WAFBypassPro
from src.utils.logger import setup_logger
from src.utils.banner import display_banner


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="WAF Bypass Pro - Advanced WAF Evasion Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        '-t', '--target',
        type=str,
        help='Target URL to test WAF bypass'
    )
    
    parser.add_argument(
        '-p', '--payload',
        type=str,
        help='Specific payload to test (default: use built-in payloads)'
    )
    
    parser.add_argument(
        '-m', '--method',
        choices=['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
        default='GET',
        help='HTTP method to use'
    )
    
    parser.add_argument(
        '-e', '--evasion',
        choices=['encoding', 'fragmentation', 'obfuscation', 'case', 'comment', 'unicode', 'all'],
        default='all',
        help='Evasion technique to use'
    )
    
    parser.add_argument(
        '--detect-waf',
        action='store_true',
        help='Detect WAF type before testing bypasses'
    )
    
    parser.add_argument(
        '--payload-type',
        choices=['sqli', 'xss', 'rce', 'lfi', 'xxe', 'ssti', 'all'],
        default='all',
        help='Type of payloads to test'
    )
    
    parser.add_argument(
        '-o', '--output',
        type=str,
        default='reports',
        help='Output directory for reports'
    )
    
    parser.add_argument(
        '-f', '--format',
        choices=['html', 'json', 'csv', 'txt'],
        default='html',
        help='Report output format'
    )
    
    parser.add_argument(
        '--threads',
        type=int,
        default=10,
        help='Number of threads to use'
    )
    
    parser.add_argument(
        '--delay',
        type=float,
        default=0.5,
        help='Delay between requests (seconds)'
    )
    
    parser.add_argument(
        '--timeout',
        type=int,
        default=10,
        help='Request timeout (seconds)'
    )
    
    parser.add_argument(
        '--proxy',
        type=str,
        help='Proxy URL (http://proxy:port)'
    )
    
    parser.add_argument(
        '--user-agent',
        type=str,
        help='Custom User-Agent string'
    )
    
    parser.add_argument(
        '--headers',
        type=str,
        help='Custom headers (JSON format)'
    )
    
    parser.add_argument(
        '--gui',
        action='store_true',
        help='Launch graphical user interface'
    )
    
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Enable verbose output'
    )
    
    parser.add_argument(
        '--config',
        type=str,
        default='config/default.yaml',
        help='Configuration file path'
    )
    
    return parser.parse_args()


def main():
    """Main entry point for WAF Bypass Pro."""
    # Display banner
    display_banner()
    
    # Parse arguments
    args = parse_arguments()
    
    # Setup logging
    logger = setup_logger(verbose=args.verbose)
    
    try:
        # Initialize WAF Bypass Pro
        waf_bypass = WAFBypassPro(config_path=args.config, logger=logger)
        
        # Launch GUI mode
        if args.gui:
            logger.info("Launching GUI mode...")
            waf_bypass.launch_gui()
            return
        
        # CLI mode - require target
        if not args.target:
            logger.error("Target URL required for CLI mode. Use --gui for GUI mode.")
            sys.exit(1)
        
        # Detect WAF if requested
        if args.detect_waf:
            logger.info(f"Detecting WAF for {args.target}...")
            waf_info = waf_bypass.detect_waf(args.target)
            logger.info(f"WAF Detection Result: {waf_info}")
        
        # Run WAF bypass tests
        logger.info(f"Starting WAF bypass tests on {args.target}")
        results = waf_bypass.run_bypass_tests(
            target=args.target,
            payload=args.payload,
            method=args.method,
            evasion_techniques=args.evasion,
            payload_types=args.payload_type,
            output_dir=args.output,
            output_format=args.format,
            threads=args.threads,
            delay=args.delay,
            timeout=args.timeout,
            proxy=args.proxy,
            user_agent=args.user_agent,
            custom_headers=args.headers
        )
        
        if results:
            successful_bypasses = len([r for r in results.get('bypass_results', []) if r.get('bypassed')])
            logger.info(f"Bypass tests completed. {successful_bypasses} successful bypasses found.")
        else:
            logger.warning("Bypass tests completed with no successful bypasses.")
            
    except KeyboardInterrupt:
        logger.info("\nTesting interrupted by user.")
        sys.exit(0)
    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()

