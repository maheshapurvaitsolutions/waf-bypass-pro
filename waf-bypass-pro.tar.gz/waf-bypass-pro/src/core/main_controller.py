"""
Main Controller for WAF Bypass Pro

This module contains the main controller class that orchestrates all
WAF detection, payload generation, evasion testing, and reporting activities.
"""

import os
import json
import time
import uuid
from pathlib import Path
from typing import Dict, List, Optional, Any
from concurrent.futures import ThreadPoolExecutor, as_completed

from ..detection.waf_detector import WAFDetector
from ..evasion.evasion_engine import EvasionEngine
from ..payloads.payload_manager import PayloadManager
from ..utils.http_client import HTTPClient
from ..utils.report_generator import ReportGenerator


class WAFBypassPro:
    """Main controller class for WAF Bypass Pro application."""
    
    def __init__(self, config_path: str = None, logger=None):
        """Initialize WAF Bypass Pro with configuration and logger."""
        self.logger = logger
        self.config = self._load_config(config_path)
        
        # Initialize core components
        self.waf_detector = WAFDetector(self.config, self.logger)
        self.evasion_engine = EvasionEngine(self.config, self.logger)
        self.payload_manager = PayloadManager(self.config, self.logger)
        self.http_client = HTTPClient(self.config, self.logger)
        self.report_generator = ReportGenerator(self.config, self.logger)
        
        self.logger.info("WAF Bypass Pro initialized successfully")
    
    def detect_waf(self, target: str) -> Dict[str, Any]:
        """Detect WAF type and configuration for the target."""
        self.logger.info(f"Starting WAF detection for {target}")
        
        try:
            waf_info = self.waf_detector.detect(target)
            
            if waf_info.get('detected'):
                self.logger.info(f"WAF detected: {waf_info['name']} (Confidence: {waf_info['confidence']}%)")
            else:
                self.logger.info("No WAF detected or unrecognized WAF type")
            
            return waf_info
            
        except Exception as e:
            self.logger.error(f"WAF detection failed: {str(e)}")
            return {'detected': False, 'error': str(e)}
    
    def run_bypass_tests(self, target: str, payload: str = None, method: str = 'GET',
                        evasion_techniques: str = 'all', payload_types: str = 'all',
                        output_dir: str = 'reports', output_format: str = 'html',
                        threads: int = 10, delay: float = 0.5, timeout: int = 10,
                        proxy: str = None, user_agent: str = None, 
                        custom_headers: str = None) -> Dict[str, Any]:
        """Run comprehensive WAF bypass tests."""
        
        session_id = str(uuid.uuid4())
        start_time = time.time()
        
        self.logger.info(f"Starting WAF bypass tests for {target} (Session: {session_id[:8]})")
        
        try:
            # Setup HTTP client with custom configuration
            self._configure_http_client(proxy, user_agent, custom_headers, timeout)
            
            # Detect WAF first
            waf_info = self.detect_waf(target)
            
            # Get payloads to test
            if payload:
                payloads = [{'type': 'custom', 'payload': payload}]
            else:
                payloads = self._get_test_payloads(payload_types)
            
            # Get evasion techniques
            evasion_methods = self._get_evasion_techniques(evasion_techniques, waf_info)
            
            self.logger.info(f"Testing {len(payloads)} payloads with {len(evasion_methods)} evasion techniques")
            
            # Run bypass tests
            bypass_results = self._execute_bypass_tests(
                target, payloads, evasion_methods, method, threads, delay
            )
            
            # Calculate statistics
            stats = self._calculate_statistics(bypass_results, start_time)
            
            # Compile results
            results = {
                'session_id': session_id,
                'target': target,
                'waf_info': waf_info,
                'bypass_results': bypass_results,
                'statistics': stats,
                'timestamp': time.time()
            }
            
            # Generate report
            report_path = self.report_generator.generate_report(
                results, output_dir, output_format, session_id
            )
            
            results['report_path'] = report_path
            
            successful_bypasses = len([r for r in bypass_results if r.get('bypassed')])
            self.logger.info(f"Bypass tests completed. {successful_bypasses} successful bypasses found.")
            
            return results
            
        except Exception as e:
            self.logger.error(f"Bypass tests failed: {str(e)}")
            raise
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration from file or use defaults."""
        default_config = {
            'http': {
                'timeout': 10,
                'retries': 3,
                'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            'payloads': {
                'sqli': True,
                'xss': True,
                'rce': True,
                'lfi': True,
                'xxe': True,
                'ssti': True
            },
            'evasion': {
                'encoding': True,
                'case_manipulation': True,
                'comment_insertion': True,
                'unicode_normalization': True,
                'fragmentation': True,
                'obfuscation': True
            }
        }
        
        if config_path and os.path.exists(config_path):
            try:
                import yaml
                with open(config_path, 'r') as f:
                    file_config = yaml.safe_load(f)
                    default_config.update(file_config)
            except Exception as e:
                self.logger.warning(f"Could not load config file: {e}")
        
        return default_config
    
    def _configure_http_client(self, proxy: str, user_agent: str, 
                              custom_headers: str, timeout: int):
        """Configure HTTP client with custom settings."""
        config = {
            'timeout': timeout,
            'proxy': proxy,
            'user_agent': user_agent or self.config['http']['user_agent']
        }
        
        if custom_headers:
            try:
                config['headers'] = json.loads(custom_headers)
            except json.JSONDecodeError:
                self.logger.warning("Invalid JSON format for custom headers")
        
        self.http_client.update_config(config)
    
    def _get_test_payloads(self, payload_types: str) -> List[Dict[str, str]]:
        """Get payloads based on specified types."""
        if payload_types == 'all':
            types = ['sqli', 'xss', 'rce', 'lfi', 'xxe', 'ssti']
        else:
            types = [payload_types]
        
        payloads = []
        for payload_type in types:
            type_payloads = self.payload_manager.get_payloads(payload_type)
            payloads.extend(type_payloads)
        
        return payloads
    
    def _get_evasion_techniques(self, evasion_techniques: str, waf_info: Dict = None) -> List[str]:
        """Get evasion techniques based on specification and detected WAF."""
        if evasion_techniques == 'all':
            techniques = self.evasion_engine.get_advanced_bypass_techniques()
            
            # Add WAF-specific techniques if WAF is detected
            if waf_info and waf_info.get('detected'):
                waf_name = waf_info.get('name', '').lower()
                self.logger.info(f"Adding WAF-specific bypass techniques for {waf_name}")
                techniques.extend(['waf_specific_' + waf_name])
            
            return techniques
        else:
            return [evasion_techniques]
    
    def _execute_bypass_tests(self, target: str, payloads: List[Dict], 
                             evasion_methods: List[str], method: str, 
                             threads: int, delay: float) -> List[Dict[str, Any]]:
        """Execute bypass tests using multiple threads."""
        results = []
        
        # Create test cases (payload + evasion combinations)
        test_cases = []
        for payload_data in payloads:
            for evasion_method in evasion_methods:
                test_cases.append({
                    'payload_data': payload_data,
                    'evasion_method': evasion_method,
                    'target': target,
                    'method': method
                })
        
        # Execute tests with thread pool
        with ThreadPoolExecutor(max_workers=threads) as executor:
            future_to_test = {}
            
            for test_case in test_cases:
                future = executor.submit(self._execute_single_test, test_case)
                future_to_test[future] = test_case
                
                # Add delay between submissions
                time.sleep(delay / threads)
            
            # Collect results
            for future in as_completed(future_to_test):
                test_case = future_to_test[future]
                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    self.logger.error(f"Test case failed: {str(e)}")
                    results.append({
                        'payload': test_case['payload_data']['payload'],
                        'evasion': test_case['evasion_method'],
                        'bypassed': False,
                        'error': str(e)
                    })
        
        return results
    
    def _execute_single_test(self, test_case: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a single bypass test."""
        payload_data = test_case['payload_data']
        evasion_method = test_case['evasion_method']
        target = test_case['target']
        method = test_case['method']
        
        # Apply evasion technique to payload
        evaded_payload = self.evasion_engine.apply_evasion(
            payload_data['payload'], evasion_method
        )
        
        # Test the payload
        test_url = f"{target}?test={evaded_payload}" if method == 'GET' else target
        data = {'test': evaded_payload} if method == 'POST' else None
        
        try:
            response = self.http_client.request(method, test_url, data=data)
            
            # Analyze response for bypass indicators
            bypassed = self._analyze_response_for_bypass(response, payload_data)
            
            return {
                'payload': payload_data['payload'],
                'payload_type': payload_data['type'],
                'evasion': evasion_method,
                'evaded_payload': evaded_payload,
                'bypassed': bypassed,
                'status_code': response.status_code if response else None,
                'response_length': len(response.content) if response else 0,
                'response_time': getattr(response, 'elapsed', None)
            }
            
        except Exception as e:
            return {
                'payload': payload_data['payload'],
                'payload_type': payload_data['type'],
                'evasion': evasion_method,
                'evaded_payload': evaded_payload,
                'bypassed': False,
                'error': str(e)
            }
    
    def _analyze_response_for_bypass(self, response, payload_data: Dict) -> bool:
        """Analyze HTTP response to determine if WAF was bypassed."""
        if not response:
            return False
        
        # First send a baseline request without payload to compare
        baseline_response = self._get_baseline_response(response.url.split('?')[0])
        
        # WAF blocking indicators
        blocking_status_codes = [400, 403, 406, 409, 429, 451, 501, 503]
        waf_blocking_patterns = [
            'blocked', 'forbidden', 'access denied', 'security violation',
            'firewall', 'waf', 'protection', 'filtered', 'not allowed',
            'malicious', 'attack', 'injection', 'suspicious', 'threat',
            'cloudflare', 'incapsula', 'sucuri', 'akamai', 'barracuda',
            'mod_security', 'modsecurity', 'web application firewall',
            'request blocked', 'access blocked', 'security alert'
        ]
        
        response_text = response.text.lower()
        
        # If response contains WAF blocking indicators, it's blocked
        for indicator in waf_blocking_patterns:
            if indicator in response_text:
                return False
        
        # If status code indicates blocking
        if response.status_code in blocking_status_codes:
            return False
        
        # Check if response is significantly different from baseline
        if baseline_response:
            # If baseline gets blocked but our payload doesn't, it might be a bypass
            if (baseline_response.status_code in blocking_status_codes and 
                response.status_code not in blocking_status_codes):
                return True
            
            # If response content is dramatically different, might indicate processing
            baseline_len = len(baseline_response.text)
            response_len = len(response.text)
            
            # If our payload response is much shorter, it might be blocked
            if baseline_len > 0 and response_len < baseline_len * 0.5:
                return False
        
        # For successful responses, check if payload was actually processed
        if 200 <= response.status_code < 300:
            return self._check_payload_execution(response, payload_data)
        
        # Default to not bypassed for unclear cases
        return False
    
    def _calculate_statistics(self, results: List[Dict], start_time: float) -> Dict[str, Any]:
        """Calculate test statistics."""
        total_tests = len(results)
        successful_bypasses = len([r for r in results if r.get('bypassed')])
        failed_tests = len([r for r in results if 'error' in r])
        
        return {
            'total_tests': total_tests,
            'successful_bypasses': successful_bypasses,
            'failed_tests': failed_tests,
            'success_rate': (successful_bypasses / total_tests * 100) if total_tests > 0 else 0,
            'execution_time': time.time() - start_time
        }
    
    def _get_baseline_response(self, url: str):
        """Get baseline response without any payload for comparison."""
        try:
            return self.http_client.get(url)
        except Exception as e:
            self.logger.debug(f"Failed to get baseline response: {str(e)}")
            return None
    
    def _check_payload_execution(self, response, payload_data: Dict) -> bool:
        """Check if payload was actually executed/processed by the application."""
        payload_type = payload_data.get('type', '')
        payload = payload_data.get('payload', '')
        response_text = response.text.lower()
        
        # For XSS payloads, check if script tags or JavaScript executed
        if payload_type == 'xss':
            xss_indicators = ['<script', 'javascript:', 'onerror', 'onload', 'alert(']
            for indicator in xss_indicators:
                if indicator.lower() in response_text:
                    return True
        
        # For SQL injection, check for SQL error messages or data
        elif payload_type == 'sqli':
            sql_error_patterns = [
                'sql syntax', 'mysql_fetch', 'ora-', 'microsoft jet database',
                'odbc microsoft access', 'sqlite', 'postgresql', 'warning: mysql',
                'syntax error', 'quoted string not properly terminated',
                'invalid column name', 'table or view does not exist'
            ]
            for pattern in sql_error_patterns:
                if pattern in response_text:
                    return True
        
        # For RCE, check for command execution indicators
        elif payload_type == 'rce':
            rce_indicators = [
                'uid=', 'gid=', 'groups=', 'root:', '/bin/', '/etc/passwd',
                'directory of', 'volume in drive', 'command not found'
            ]
            for indicator in rce_indicators:
                if indicator in response_text:
                    return True
        
        # For LFI, check for file content indicators
        elif payload_type == 'lfi':
            lfi_indicators = [
                'root:x:0:0', '[boot loader]', '[extensions]', '<?php',
                '#!/bin/', 'www-data:', 'nobody:'
            ]
            for indicator in lfi_indicators:
                if indicator in response_text:
                    return True
        
        # For SSTI, check for template execution
        elif payload_type == 'ssti':
            # Check if mathematical expressions were evaluated
            if '49' in response_text and '7*7' in payload:  # 7*7=49
                return True
            if '14' in response_text and '7*\'7\'' in payload:  # 7*'7'=7777...
                return False  # This should not evaluate to 14
        
        # Generic check: if payload appears unmodified in response, it might be reflected
        if payload.lower() in response_text:
            return True
        
        # Default to False if no clear execution indicators
        return False
    
    def launch_gui(self):
        """Launch web-based GUI interface."""
        self.logger.info("GUI interface not implemented yet")
        # TODO: Implement GUI interface

