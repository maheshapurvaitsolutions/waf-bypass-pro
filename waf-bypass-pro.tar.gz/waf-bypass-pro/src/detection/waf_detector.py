"""
WAF Detection Module using wafw00f

This module integrates with wafw00f to detect Web Application Firewalls.
"""

import subprocess
import json
import re
from typing import Dict, Any, List
from urllib.parse import urlparse


class WAFDetector:
    """WAF detection using wafw00f and custom detection methods."""
    
    def __init__(self, config: Dict[str, Any], logger):
        """Initialize WAF detector."""
        self.config = config
        self.logger = logger
        
        # WAF signatures for custom detection
        self.waf_signatures = {
            'cloudflare': {
                'headers': ['cf-ray', 'cf-cache-status', '__cfduid'],
                'cookies': ['__cfduid', '__cfuid'],
                'content': ['cloudflare', 'attention required']
            },
            'aws_waf': {
                'headers': ['x-amz-cf-id', 'x-amz-request-id'],
                'content': ['request blocked']
            },
            'akamai': {
                'headers': ['akamai-ghost-ip', 'akamai-edgescape'],
                'content': ['reference #', 'akamai']
            },
            'incapsula': {
                'headers': ['x-iinfo'],
                'cookies': ['incap_ses', 'visid_incap'],
                'content': ['incap_ses', 'incapsula']
            },
            'sucuri': {
                'headers': ['x-sucuri-id', 'x-sucuri-cache'],
                'content': ['sucuri', 'access denied']
            },
            'barracuda': {
                'content': ['barracuda', 'barra', 'web filter']
            },
            'f5_big_ip': {
                'headers': ['x-wa-info'],
                'cookies': ['bigipserver', 'f5-ltm-pool'],
                'content': ['f5 networks', 'bigip']
            }
        }
    
    def detect(self, target: str) -> Dict[str, Any]:
        """Detect WAF for the given target using multiple methods."""
        self.logger.info(f"Starting WAF detection for {target}")
        
        # Parse target URL
        parsed_url = urlparse(target)
        if not parsed_url.scheme:
            target = f"http://{target}"
        
        # Primary detection using wafw00f
        wafw00f_result = self._detect_with_wafw00f(target)
        
        # Secondary detection with custom methods
        custom_result = self._detect_with_custom_methods(target)
        
        # Combine results
        result = self._combine_detection_results(wafw00f_result, custom_result)
        
        self.logger.info(f"WAF detection completed for {target}")
        return result
    
    def _detect_with_wafw00f(self, target: str) -> Dict[str, Any]:
        """Use wafw00f for WAF detection."""
        self.logger.debug(f"Running wafw00f detection on {target}")
        
        try:
            # Run wafw00f with verbose output and JSON format if available
            cmd = ["wafw00f", "-v", target]
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                return self._parse_wafw00f_output(result.stdout, result.stderr)
            else:
                self.logger.warning(f"wafw00f returned non-zero exit code: {result.returncode}")
                return {'detected': False, 'method': 'wafw00f', 'error': result.stderr}
                
        except subprocess.TimeoutExpired:
            self.logger.warning("wafw00f detection timed out")
            return {'detected': False, 'method': 'wafw00f', 'error': 'Timeout'}
        except Exception as e:
            self.logger.error(f"wafw00f detection failed: {str(e)}")
            return {'detected': False, 'method': 'wafw00f', 'error': str(e)}
    
    def _parse_wafw00f_output(self, stdout: str, stderr: str) -> Dict[str, Any]:
        """Parse wafw00f output to extract WAF information."""
        result = {
            'detected': False,
            'method': 'wafw00f',
            'waf_name': None,
            'confidence': 0,
            'details': {}
        }
        
        try:
            # Look for WAF detection patterns in output
            lines = stdout.split('\n') + stderr.split('\n')
            
            for line in lines:
                line = line.strip()
                
                # Check for positive detection
                if 'is behind' in line.lower():
                    # Pattern: "The site <url> is behind <WAF_NAME> WAF"
                    match = re.search(r'is behind (.+?) (?:WAF|Web Application Firewall)', line, re.IGNORECASE)
                    if match:
                        result['detected'] = True
                        result['waf_name'] = match.group(1).strip()
                        result['confidence'] = 90  # High confidence from wafw00f
                
                # Check for no WAF detected
                elif 'no waf detected' in line.lower() or 'does not seem to be behind a waf' in line.lower():
                    result['detected'] = False
                    result['confidence'] = 80
                
                # Look for specific WAF mentions
                elif any(waf in line.lower() for waf in ['cloudflare', 'incapsula', 'akamai', 'sucuri', 'barracuda']):
                    for waf_name in ['cloudflare', 'incapsula', 'akamai', 'sucuri', 'barracuda']:
                        if waf_name in line.lower():
                            result['detected'] = True
                            result['waf_name'] = waf_name.title()
                            result['confidence'] = 85
                            break
            
            # Store raw output for debugging
            result['details']['raw_output'] = stdout
            
        except Exception as e:
            self.logger.error(f"Failed to parse wafw00f output: {str(e)}")
            result['error'] = str(e)
        
        return result
    
    def _detect_with_custom_methods(self, target: str) -> Dict[str, Any]:
        """Custom WAF detection using HTTP fingerprinting."""
        self.logger.debug(f"Running custom WAF detection on {target}")
        
        from ..utils.http_client import HTTPClient
        
        result = {
            'detected': False,
            'method': 'custom',
            'waf_name': None,
            'confidence': 0,
            'indicators': []
        }
        
        try:
            # Create HTTP client for testing
            http_client = HTTPClient(self.config, self.logger)
            
            # Test normal request
            normal_response = http_client.get(target)
            if not normal_response:
                return result
            
            # Test with suspicious payload
            test_payloads = [
                "<script>alert('xss')</script>",
                "' OR '1'='1",
                "../../../etc/passwd",
                "{{7*7}}"
            ]
            
            for payload in test_payloads:
                test_url = f"{target}?test={payload}"
                response = http_client.get(test_url)
                
                if response:
                    waf_detected = self._analyze_response_for_waf(response, normal_response)
                    if waf_detected:
                        result.update(waf_detected)
                        break
            
        except Exception as e:
            self.logger.error(f"Custom WAF detection failed: {str(e)}")
            result['error'] = str(e)
        
        return result
    
    def _analyze_response_for_waf(self, suspicious_response, normal_response) -> Dict[str, Any]:
        """Analyze response patterns to detect WAF."""
        indicators = []
        detected_waf = None
        confidence = 0
        
        # Check status code changes
        if suspicious_response.status_code != normal_response.status_code:
            if suspicious_response.status_code in [403, 406, 429, 501, 503]:
                indicators.append(f"Status code changed to {suspicious_response.status_code}")
                confidence += 20
        
        # Check headers for WAF signatures
        for waf_name, signatures in self.waf_signatures.items():
            waf_indicators = 0
            
            # Check headers
            if 'headers' in signatures:
                for header in signatures['headers']:
                    if header.lower() in [h.lower() for h in suspicious_response.headers.keys()]:
                        indicators.append(f"WAF header detected: {header}")
                        waf_indicators += 1
            
            # Check cookies
            if 'cookies' in signatures:
                cookies = suspicious_response.cookies
                for cookie in signatures['cookies']:
                    if cookie in cookies:
                        indicators.append(f"WAF cookie detected: {cookie}")
                        waf_indicators += 1
            
            # Check content
            if 'content' in signatures:
                content = suspicious_response.text.lower()
                for pattern in signatures['content']:
                    if pattern.lower() in content:
                        indicators.append(f"WAF content pattern detected: {pattern}")
                        waf_indicators += 1
            
            # If multiple indicators found for this WAF
            if waf_indicators >= 1:
                detected_waf = waf_name
                confidence += waf_indicators * 25
                break
        
        if detected_waf or indicators:
            return {
                'detected': True,
                'waf_name': detected_waf,
                'confidence': min(confidence, 95),  # Cap at 95% for custom detection
                'indicators': indicators
            }
        
        return {'detected': False}
    
    def _combine_detection_results(self, wafw00f_result: Dict, custom_result: Dict) -> Dict[str, Any]:
        """Combine results from wafw00f and custom detection."""
        combined = {
            'detected': False,
            'name': 'Unknown',
            'confidence': 0,
            'methods': {
                'wafw00f': wafw00f_result,
                'custom': custom_result
            },
            'indicators': []
        }
        
        # Prioritize wafw00f results if detected
        if wafw00f_result.get('detected'):
            combined['detected'] = True
            combined['name'] = wafw00f_result.get('waf_name', 'Unknown WAF')
            combined['confidence'] = wafw00f_result.get('confidence', 80)
            combined['primary_method'] = 'wafw00f'
        
        # Use custom results if wafw00f didn't detect anything
        elif custom_result.get('detected'):
            combined['detected'] = True
            combined['name'] = custom_result.get('waf_name', 'Unknown WAF')
            combined['confidence'] = custom_result.get('confidence', 60)
            combined['primary_method'] = 'custom'
            combined['indicators'] = custom_result.get('indicators', [])
        
        # If both detected the same WAF, increase confidence
        elif (wafw00f_result.get('detected') and custom_result.get('detected') and 
              wafw00f_result.get('waf_name', '').lower() == custom_result.get('waf_name', '').lower()):
            combined['detected'] = True
            combined['name'] = wafw00f_result.get('waf_name')
            combined['confidence'] = min(95, wafw00f_result.get('confidence', 0) + 10)
            combined['primary_method'] = 'both'
        
        return combined
    
    def get_supported_wafs(self) -> List[str]:
        """Get list of supported WAF types."""
        # Run wafw00f to get supported WAFs
        try:
            result = subprocess.run(
                ["wafw00f", "-l"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                # Parse the list of supported WAFs
                wafs = []
                for line in result.stdout.split('\n'):
                    if line.strip() and not line.startswith('[') and not line.startswith('WAF'):
                        waf_name = line.strip().split()[0] if line.strip().split() else None
                        if waf_name:
                            wafs.append(waf_name)
                return wafs
        except Exception as e:
            self.logger.debug(f"Could not get supported WAFs list: {str(e)}")
        
        # Fallback to known WAFs
        return list(self.waf_signatures.keys())

