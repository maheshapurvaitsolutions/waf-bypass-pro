"""
HTTP Client for WAF Bypass Pro

Custom HTTP client with advanced features for WAF bypass testing.
"""

import requests
import urllib3
from urllib.parse import urljoin, urlparse
from typing import Dict, Any, Optional
import time
import random

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class HTTPClient:
    """Custom HTTP client for WAF bypass testing."""
    
    def __init__(self, config: Dict[str, Any], logger):
        """Initialize HTTP client with configuration."""
        self.config = config.get('http', {})
        self.logger = logger
        
        # Create session
        self.session = requests.Session()
        
        # Set default headers
        self.session.headers.update({
            'User-Agent': self.config.get('user_agent', 
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        })
        
        # Set session configuration
        self.session.verify = False
        self.session.timeout = self.config.get('timeout', 10)
        
        # Configure proxy if provided
        proxy = self.config.get('proxy')
        if proxy:
            self.session.proxies = {
                'http': proxy,
                'https': proxy
            }
    
    def update_config(self, new_config: Dict[str, Any]):
        """Update client configuration."""
        self.config.update(new_config)
        
        if 'user_agent' in new_config:
            self.session.headers['User-Agent'] = new_config['user_agent']
        
        if 'timeout' in new_config:
            self.session.timeout = new_config['timeout']
        
        if 'proxy' in new_config and new_config['proxy']:
            self.session.proxies = {
                'http': new_config['proxy'],
                'https': new_config['proxy']
            }
        
        if 'headers' in new_config:
            self.session.headers.update(new_config['headers'])
    
    def request(self, method: str, url: str, **kwargs) -> Optional[requests.Response]:
        """Make HTTP request with error handling and retries."""
        retries = self.config.get('retries', 3)
        
        for attempt in range(retries):
            try:
                response = self.session.request(
                    method=method,
                    url=url,
                    verify=False,
                    allow_redirects=True,
                    **kwargs
                )
                return response
                
            except requests.exceptions.RequestException as e:
                if attempt == retries - 1:
                    self.logger.error(f"HTTP request failed after {retries} attempts: {str(e)}")
                    return None
                
                # Wait before retry with exponential backoff
                wait_time = (2 ** attempt) + random.uniform(0, 1)
                time.sleep(wait_time)
        
        return None
    
    def get(self, url: str, **kwargs) -> Optional[requests.Response]:
        """Make GET request."""
        return self.request('GET', url, **kwargs)
    
    def post(self, url: str, **kwargs) -> Optional[requests.Response]:
        """Make POST request."""
        return self.request('POST', url, **kwargs)
    
    def put(self, url: str, **kwargs) -> Optional[requests.Response]:
        """Make PUT request."""
        return self.request('PUT', url, **kwargs)
    
    def delete(self, url: str, **kwargs) -> Optional[requests.Response]:
        """Make DELETE request."""
        return self.request('DELETE', url, **kwargs)
    
    def patch(self, url: str, **kwargs) -> Optional[requests.Response]:
        """Make PATCH request."""
        return self.request('PATCH', url, **kwargs)
    
    def test_connectivity(self, url: str) -> bool:
        """Test basic connectivity to target."""
        try:
            response = self.get(url, timeout=5)
            return response is not None and response.status_code < 500
        except:
            return False
    
    def get_response_fingerprint(self, url: str) -> Dict[str, Any]:
        """Get response fingerprint for WAF detection."""
        fingerprint = {
            'headers': {},
            'status_code': None,
            'server': None,
            'content_length': 0,
            'response_time': 0
        }
        
        try:
            start_time = time.time()
            response = self.get(url)
            end_time = time.time()
            
            if response:
                fingerprint['headers'] = dict(response.headers)
                fingerprint['status_code'] = response.status_code
                fingerprint['server'] = response.headers.get('Server', '')
                fingerprint['content_length'] = len(response.content)
                fingerprint['response_time'] = end_time - start_time
                
        except Exception as e:
            self.logger.debug(f"Failed to get response fingerprint: {str(e)}")
        
        return fingerprint

