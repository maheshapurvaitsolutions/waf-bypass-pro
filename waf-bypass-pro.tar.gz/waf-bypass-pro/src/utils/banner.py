"""
Banner display utility for WAF Bypass Pro
"""

def display_banner():
    """Display the application banner."""
    banner = """

╭────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────╮
│                                                                                                                                            │
│                                                                                                                                            │
│                           ██╗    ██╗ █████╗ ███████╗    ██████╗ ██╗   ██╗██████╗  █████╗ ███████╗███████╗                                │
│                           ██║    ██║██╔══██╗██╔════╝    ██╔══██╗╚██╗ ██╔╝██╔══██╗██╔══██╗██╔════╝██╔════╝                                │
│                           ██║ █╗ ██║███████║█████╗      ██████╔╝ ╚████╔╝ ██████╔╝███████║███████╗███████╗                                │
│                           ██║███╗██║██╔══██║██╔══╝      ██╔══██╗  ╚██╔╝  ██╔═══╝ ██╔══██║╚════██║╚════██║                                │
│                           ╚███╔███╔╝██║  ██║██║         ██████╔╝   ██║   ██║     ██║  ██║███████║███████║                                │
│                            ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝         ╚═════╝    ╚═╝   ╚═╝     ╚═╝  ╚═╝╚══════╝╚══════╝                                │
│                                                               ██████╗ ██████╗  ██████╗                                                     │
│                                                               ██╔══██╗██╔══██╗██╔═══██╗                                                    │
│                                                               ██████╔╝██████╔╝██║   ██║                                                    │
│                                                               ██╔═══╝ ██╔══██╗██║   ██║                                                    │
│                                                               ██║     ██║  ██║╚██████╔╝                                                    │
│                                                               ╚═╝     ╚═╝  ╚═╝ ╚═════╝                                                     │
│                                                                                                                                            │
│                                                                                                                                            │
╰────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────╯
╭──────────────────────────────────────────────────────── Welcome to WAF Bypass Pro ──────────────────────────────────────────────────────────╮
│                                                                                                                                            │
│                                                                                                                                            │
│      WAF Bypass Pro - Advanced Web Application Firewall Bypass Tool                                                                       │
│                                                                                                                                            │
│      Version: 1.0.0                                                                                                                        │
│      Author: Security Research Team                                                                                                        │
│      License: Educational Use Only                                                                                                         │
│                                                                                                                                            │
│      ⚠️  WARNING: This tool is for authorized security testing only.                                                                        │
│         Ensure you have proper permission before testing any target.                                                                       │
│                                                                                                                                            │
│      Features:                                                                                                                             │
│      • WAF Detection and Fingerprinting                                                                                                   │
│      • Advanced Payload Encoding and Obfuscation                                                                                          │
│      • Multiple Evasion Techniques (Unicode, Case, Comments, etc.)                                                                        │
│      • Support for various attack types (SQLi, XSS, RCE, LFI, etc.)                                                                      │
│      • Automated bypass testing with detailed reporting                                                                                    │
│      • Multi-threaded testing capabilities                                                                                                │
│                                                                                                                                            │
│                                                                                                                                            │
╰────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────╯

    """
    print(banner)

