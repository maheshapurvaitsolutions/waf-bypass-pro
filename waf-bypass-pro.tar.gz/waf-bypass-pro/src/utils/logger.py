"""
Logging configuration for WAF Bypass Pro
"""

import logging
import sys
from datetime import datetime
from rich.logging import RichHandler
from rich.console import Console

console = Console()

def setup_logger(name="WAFBypassPro", verbose=False):
    """Setup logging configuration."""
    
    # Create logger
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # Create rich handler for colored output
    rich_handler = RichHandler(
        console=console,
        show_time=True,
        show_path=False,
        markup=True
    )
    
    # Set format
    formatter = logging.Formatter(
        "%(message)s",
        datefmt="%m/%d/%y %H:%M:%S"
    )
    rich_handler.setFormatter(formatter)
    
    # Add handler to logger
    logger.addHandler(rich_handler)
    
    # Create file handler for detailed logs
    log_filename = f"logs/waf_bypass_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    try:
        import os
        os.makedirs('logs', exist_ok=True)
        
        file_handler = logging.FileHandler(log_filename)
        file_handler.setLevel(logging.DEBUG)
        
        file_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)
        
    except Exception as e:
        logger.warning(f"Could not create log file: {e}")
    
    return logger

