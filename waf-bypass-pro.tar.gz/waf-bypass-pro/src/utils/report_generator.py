"""
Report Generator for WAF Bypass Pro

This module generates detailed reports of WAF bypass test results.
"""

import os
import json
import csv
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List


class ReportGenerator:
    """Generator for various report formats."""
    
    def __init__(self, config: Dict[str, Any], logger):
        """Initialize report generator."""
        self.config = config
        self.logger = logger
    
    def generate_report(self, results: Dict[str, Any], output_dir: str, 
                       format_type: str, session_id: str) -> str:
        """Generate a report in the specified format."""
        
        # Ensure output directory exists
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate timestamp for filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Generate report based on format
        if format_type == 'html':
            return self._generate_html_report(results, output_dir, timestamp, session_id)
        elif format_type == 'json':
            return self._generate_json_report(results, output_dir, timestamp, session_id)
        elif format_type == 'csv':
            return self._generate_csv_report(results, output_dir, timestamp, session_id)
        elif format_type == 'txt':
            return self._generate_txt_report(results, output_dir, timestamp, session_id)
        else:
            self.logger.error(f"Unsupported report format: {format_type}")
            return None
    
    def _generate_html_report(self, results: Dict[str, Any], output_dir: str, 
                             timestamp: str, session_id: str) -> str:
        """Generate HTML report."""
        filename = f"waf_bypass_report_{timestamp}.html"
        filepath = os.path.join(output_dir, filename)
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(self._get_html_template(results, session_id))
            
            self.logger.info(f"HTML report generated: {filepath}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Failed to generate HTML report: {str(e)}")
            return None
    
    def _generate_json_report(self, results: Dict[str, Any], output_dir: str,
                             timestamp: str, session_id: str) -> str:
        """Generate JSON report."""
        filename = f"waf_bypass_report_{timestamp}.json"
        filepath = os.path.join(output_dir, filename)
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, default=str)
            
            self.logger.info(f"JSON report generated: {filepath}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Failed to generate JSON report: {str(e)}")
            return None
    
    def _generate_csv_report(self, results: Dict[str, Any], output_dir: str,
                            timestamp: str, session_id: str) -> str:
        """Generate CSV report."""
        filename = f"waf_bypass_report_{timestamp}.csv"
        filepath = os.path.join(output_dir, filename)
        
        try:
            with open(filepath, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                
                # Write header
                writer.writerow([
                    'Payload Type', 'Payload', 'Evasion Technique', 
                    'Evaded Payload', 'Bypassed', 'Status Code', 
                    'Response Length', 'Error'
                ])
                
                # Write data
                for result in results.get('bypass_results', []):
                    writer.writerow([
                        result.get('payload_type', ''),
                        result.get('payload', ''),
                        result.get('evasion', ''),
                        result.get('evaded_payload', ''),
                        result.get('bypassed', False),
                        result.get('status_code', ''),
                        result.get('response_length', 0),
                        result.get('error', '')
                    ])
            
            self.logger.info(f"CSV report generated: {filepath}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Failed to generate CSV report: {str(e)}")
            return None
    
    def _generate_txt_report(self, results: Dict[str, Any], output_dir: str,
                            timestamp: str, session_id: str) -> str:
        """Generate plain text report."""
        filename = f"waf_bypass_report_{timestamp}.txt"
        filepath = os.path.join(output_dir, filename)
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write("WAF BYPASS PRO - TEST REPORT\n")
                f.write("=" * 50 + "\n\n")
                
                f.write(f"Session ID: {session_id}\n")
                f.write(f"Target: {results.get('target', 'Unknown')}\n")
                f.write(f"Timestamp: {datetime.fromtimestamp(results.get('timestamp', 0))}\n\n")
                
                # WAF Detection Results
                waf_info = results.get('waf_info', {})
                f.write("WAF DETECTION RESULTS\n")
                f.write("-" * 25 + "\n")
                f.write(f"WAF Detected: {waf_info.get('detected', False)}\n")
                if waf_info.get('detected'):
                    f.write(f"WAF Name: {waf_info.get('name', 'Unknown')}\n")
                    f.write(f"Confidence: {waf_info.get('confidence', 0)}%\n")
                f.write("\n")
                
                # Statistics
                stats = results.get('statistics', {})
                f.write("TEST STATISTICS\n")
                f.write("-" * 15 + "\n")
                f.write(f"Total Tests: {stats.get('total_tests', 0)}\n")
                f.write(f"Successful Bypasses: {stats.get('successful_bypasses', 0)}\n")
                f.write(f"Failed Tests: {stats.get('failed_tests', 0)}\n")
                f.write(f"Success Rate: {stats.get('success_rate', 0):.2f}%\n")
                f.write(f"Execution Time: {stats.get('execution_time', 0):.2f} seconds\n\n")
                
                # Bypass Results
                f.write("BYPASS TEST RESULTS\n")
                f.write("-" * 20 + "\n")
                
                for i, result in enumerate(results.get('bypass_results', []), 1):
                    f.write(f"Test {i}:\n")
                    f.write(f"  Payload Type: {result.get('payload_type', '')}\n")
                    f.write(f"  Original Payload: {result.get('payload', '')}\n")
                    f.write(f"  Evasion Technique: {result.get('evasion', '')}\n")
                    f.write(f"  Evaded Payload: {result.get('evaded_payload', '')}\n")
                    f.write(f"  Bypassed: {result.get('bypassed', False)}\n")
                    f.write(f"  Status Code: {result.get('status_code', '')}\n")
                    f.write(f"  Response Length: {result.get('response_length', 0)}\n")
                    if 'error' in result:
                        f.write(f"  Error: {result['error']}\n")
                    f.write("\n")
            
            self.logger.info(f"Text report generated: {filepath}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Failed to generate text report: {str(e)}")
            return None
    
    def _get_html_template(self, results: Dict[str, Any], session_id: str) -> str:
        """Get HTML template for the report."""
        waf_info = results.get('waf_info', {})
        stats = results.get('statistics', {})
        bypass_results = results.get('bypass_results', [])
        
        # Count successful bypasses
        successful_bypasses = [r for r in bypass_results if r.get('bypassed')]
        
        # Build HTML parts separately to avoid f-string complexity
        waf_type_row = ""
        confidence_row = ""
        if waf_info.get('detected'):
            waf_type_row = f'<div class="info-item"><span class="info-label">WAF Type:</span><span class="info-value">{waf_info.get("name", "Unknown")}</span></div>'
            confidence_row = f'<div class="info-item"><span class="info-label">Detection Confidence:</span><span class="info-value">{waf_info.get("confidence", 0)}%</span></div>'
        
        # Build successful bypasses section
        successful_section = ""
        if successful_bypasses:
            successful_rows = ""
            for result in successful_bypasses:
                payload = result.get('payload', '').replace('<', '&lt;').replace('>', '&gt;')
                evaded = result.get('evaded_payload', '').replace('<', '&lt;').replace('>', '&gt;')
                successful_rows += f"""
                        <tr>
                            <td>{result.get('payload_type', '')}</td>
                            <td class="payload-cell">{payload}</td>
                            <td>{result.get('evasion', '')}</td>
                            <td class="payload-cell">{evaded}</td>
                            <td><span class="badge badge-success">BYPASSED</span></td>
                        </tr>"""
            
            successful_section = f"""
            <div class="section">
                <h2>Successful Bypasses ({len(successful_bypasses)})</h2>
                <table class="results-table">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Original Payload</th>
                            <th>Evasion</th>
                            <th>Evaded Payload</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>{successful_rows}
                    </tbody>
                </table>
            </div>"""
        
        # Build all results rows
        all_results_rows = ""
        for result in bypass_results:
            badge_class = "badge-success" if result.get('bypassed') else "badge-danger"
            badge_text = "BYPASSED" if result.get('bypassed') else "BLOCKED"
            payload_preview = result.get('payload', '')[:100]
            if len(result.get('payload', '')) > 100:
                payload_preview += '...'
            payload_preview = payload_preview.replace('<', '&lt;').replace('>', '&gt;')
            
            all_results_rows += f"""
                        <tr>
                            <td>{result.get('payload_type', '')}</td>
                            <td class="payload-cell">{payload_preview}</td>
                            <td>{result.get('evasion', '')}</td>
                            <td><span class="badge {badge_class}">{badge_text}</span></td>
                            <td>{result.get('status_code', 'N/A')}</td>
                        </tr>"""
        
        html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WAF Bypass Pro - Test Report</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 8px 8px 0 0;
        }}
        .header h1 {{
            margin: 0;
            font-size: 2.5em;
        }}
        .header p {{
            margin: 10px 0 0 0;
            opacity: 0.9;
        }}
        .content {{
            padding: 30px;
        }}
        .section {{
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            background-color: #fafafa;
        }}
        .section h2 {{
            margin-top: 0;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }}
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }}
        .stat-card {{
            background: white;
            padding: 15px;
            border-radius: 6px;
            border-left: 4px solid #667eea;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }}
        .stat-number {{
            font-size: 1.8em;
            font-weight: bold;
            color: #667eea;
        }}
        .stat-label {{
            color: #666;
            font-size: 0.9em;
        }}
        .results-table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }}
        .results-table th,
        .results-table td {{
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }}
        .results-table th {{
            background-color: #667eea;
            color: white;
            font-weight: 600;
        }}
        .results-table tr:hover {{
            background-color: #f8f9fa;
        }}
        .badge {{
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8em;
            font-weight: bold;
        }}
        .badge-success {{
            background-color: #d4edda;
            color: #155724;
        }}
        .badge-danger {{
            background-color: #f8d7da;
            color: #721c24;
        }}
        .payload-cell {{
            max-width: 300px;
            word-wrap: break-word;
            font-family: monospace;
            font-size: 0.85em;
        }}
        .info-grid {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }}
        .info-item {{
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }}
        .info-label {{
            font-weight: 600;
            color: #333;
        }}
        .info-value {{
            color: #666;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>WAF Bypass Pro</h1>
            <p>Comprehensive WAF Bypass Test Report</p>
        </div>
        
        <div class="content">
            <!-- Test Information -->
            <div class="section">
                <h2>Test Information</h2>
                <div class="info-grid">
                    <div>
                        <div class="info-item">
                            <span class="info-label">Session ID:</span>
                            <span class="info-value">{session_id[:8]}...</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Target URL:</span>
                            <span class="info-value">{results.get('target', 'Unknown')}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Test Date:</span>
                            <span class="info-value">{datetime.fromtimestamp(results.get('timestamp', 0)).strftime('%Y-%m-%d %H:%M:%S')}</span>
                        </div>
                    </div>
                    <div>
                        <div class="info-item">
                            <span class="info-label">WAF Detected:</span>
                            <span class="info-value">{'Yes' if waf_info.get('detected') else 'No'}</span>
                        </div>
                        {waf_type_row}
                        {confidence_row}
                    </div>
                </div>
            </div>
            
            <!-- Statistics -->
            <div class="section">
                <h2>Test Statistics</h2>
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-number">{stats.get('total_tests', 0)}</div>
                        <div class="stat-label">Total Tests</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">{stats.get('successful_bypasses', 0)}</div>
                        <div class="stat-label">Successful Bypasses</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">{stats.get('success_rate', 0):.1f}%</div>
                        <div class="stat-label">Success Rate</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">{stats.get('execution_time', 0):.1f}s</div>
                        <div class="stat-label">Execution Time</div>
                    </div>
                </div>
            </div>
            
            {successful_section}
            
            <!-- All Results -->
            <div class="section">
                <h2>All Test Results</h2>
                <table class="results-table">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Original Payload</th>
                            <th>Evasion</th>
                            <th>Status</th>
                            <th>HTTP Code</th>
                        </tr>
                    </thead>
                    <tbody>{all_results_rows}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
"""
        
        return html

